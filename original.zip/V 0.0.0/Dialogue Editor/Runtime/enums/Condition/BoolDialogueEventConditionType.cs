using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BoolDialogueEventConditionType 
{
    True = 1,
    False = 2,
}
