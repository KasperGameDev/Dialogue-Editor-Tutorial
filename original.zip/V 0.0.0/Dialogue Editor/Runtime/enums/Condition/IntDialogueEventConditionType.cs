using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum IntDialogueEventConditionType 
{
    Equals = 3,
    EqualsAndBiggerIn = 4,
    EqualsAndSmallerIn = 5,
    BiggerIn = 6,
    SmallerIn = 7,
}
