using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace KasperDev.Dialogue
{
    public enum StringDialogueEventConditionType
    {
        Equals = 3,
    }
}
