﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace KasperDev.Dialogue
{
    public enum LanguageType
    {
        English = 1,
        German = 2,
        Danish = 3,
        Spanish = 4,
        French = 5,
        Italian = 6,
        Latin = 7,
    }
}