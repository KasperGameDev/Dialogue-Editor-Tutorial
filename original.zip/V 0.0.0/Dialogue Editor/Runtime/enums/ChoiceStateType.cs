using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace KasperDev.Dialogue
{
    public enum ChoiceStateType
    {
        Hide = 1,
        GrayOut = 2,
    }
}
