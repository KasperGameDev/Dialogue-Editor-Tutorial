using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum BoolDialogueEventModifierType 
{
    SetTrue = 1,
    SetFalse = 2,
}
