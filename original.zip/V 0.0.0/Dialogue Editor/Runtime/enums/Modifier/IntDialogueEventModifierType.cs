using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum IntDialogueEventModifierType 
{
        Add = 3,
        Subtract = 4,
}
