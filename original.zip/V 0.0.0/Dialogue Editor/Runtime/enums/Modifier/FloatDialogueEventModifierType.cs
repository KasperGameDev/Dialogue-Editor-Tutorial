using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum FloatDialogueEventModifierType 
{

        Add = 3,
        Subtract = 4,
}
