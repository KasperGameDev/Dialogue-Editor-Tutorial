﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace KasperDev.Dialogue
{
    public enum EndNodeType
    {
        End = 1,
        Repeat = 2,
        RetrunToStart = 4
    }
}